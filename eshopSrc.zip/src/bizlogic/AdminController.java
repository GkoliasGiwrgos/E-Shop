
package bizlogic;


public class AdminController {
	
	// implement a method that prints all the products of a shop

	// implement a method that prints all the memberships of a shop
	
	// implement a method that prints all the cashiers of a shop
	
	// implement a method that prints all the customers/employees of a shop
	
	
	
	
	
}
