
package bizlogic;


public class BillingController {
	
	// implemet a method with name startBilling that updates the Basket.isOpen = false  
	
	// methods about billing run if basket is closed. 
	
	// implement a method that creates an Invoice for a Customer and a Basket (after checking that the basket belongs to this customer).
	
	// implement a method that checks whether an invoice is fully received: ie amountDue is zero.
	
	// implement a method that makes the payment: updates the amount fields in invoice.
	
	// implement a method that cancels a payment.
	
	// do not forget to check for negative amounts etc.
	
}
