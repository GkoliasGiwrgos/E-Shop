
package bizlogic;


public class OrderController {
	
	// all the following the methods work if the basket is open.
	
	// implement a method that computes the total cost of the products in a basket.
	
	// implement a method that checks that the Basket.total equals the sum of the prices of the products in the basket.
	
	// implemet a method that add a product to the basket (the total must be updated accordingly)
	
	// implemet a method that removes a product from the basket (the total must be updated accordingly)
	
}
