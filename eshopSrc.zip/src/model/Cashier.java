
package model;


public class Cashier {
	
	// to be implemented
	
}
