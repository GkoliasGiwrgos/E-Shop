
package model;

import java.util.Date;


public class Membership {
	
	private String memberCode;
	private Customer customer;
	private Date memberSince;
	private boolean isMember;
	
}
