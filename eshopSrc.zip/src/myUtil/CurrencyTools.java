
package myUtil;


public class CurrencyTools {
	
}
