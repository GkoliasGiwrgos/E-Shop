
package myUtil;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import model.Constants;


public class DateTools {
	
	public static String convertDateToString(Date inputDate, boolean includeTime){
		String datePattern; 
		if (includeTime){
			datePattern = Constants.DATE_FORMAT_DDMMYYYYHHMMSS;
		} else {
			datePattern = Constants.DATE_FORMAT_DDMMYYYY;
		}
		DateFormat df = new SimpleDateFormat(datePattern);  
		return df.format(inputDate);
		
	}
	
	public static String convertDateToString(Date inputDate){
		return convertDateToString(inputDate, false);
	}
	
	public static Date getCurrentDateTime(){
		return Calendar.getInstance().getTime();
	}
	
	public static String printCurrentDateTime(){
		return convertDateToString(getCurrentDateTime(), true);
	}
	
	
	
}
